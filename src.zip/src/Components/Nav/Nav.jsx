import React, { useRef } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";

function Nav() {
  const menu = useRef();
  const location = useLocation();
  const navigate = useNavigate();

  const menuhandler = () => {
    menu.current.classList.toggle("show-menu");
  };

  const handleNavClick = (hash) => {
    if (location.pathname !== "/") {
      // Pindah ke halaman home
      navigate("/");

      // Tunggu sebentar agar halaman home ter-load, lalu scroll ke elemen tujuan
      setTimeout(() => {
        const targetElement = document.getElementById(hash.replace("#", ""));
        if (targetElement) {
          targetElement.scrollIntoView({ behavior: "smooth" });
        }
      }, 500);
    } else {
      // Jika sudah di home, langsung scroll ke elemen
      document
        .getElementById(hash.replace("#", ""))
        ?.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <>
      <div className="h-[80px] flex justify-between items-center px-[12%] py-[0] relative bg-[#A67B5B]">
        <div className="flex items-center justify-center">
          <span
            className="text-2xl text-red-600 font-medium cursor-pointer"
            onClick={() => navigate("/")}
          >
            JejakCafe
          </span>
        </div>

        <div
          ref={menu}
          className="md:static absolute top-[100%] left-[-100%] md:left-[0%] z-40 gap-[20%] w-full transition-all duration-600 bg-white md:bg-[#A67B5B] md:transition-none"
        >
          <ul className="w-full flex flex-col md:flex-row gap-[15px] justify-center">
            <li className="nav-wrapper">
              <Link to="/" className="Nav-link">
                Home
              </Link>
            </li>
            <li className="nav-wrapper">
              <button
                onClick={() => handleNavClick("#category")}
                className="Nav-link"
              >
                Category
              </button>
            </li>
            <li className="nav-wrapper">
              <button
                onClick={() => handleNavClick("#popular")}
                className="Nav-link"
              >
                Popular
              </button>
            </li>
            <li className="nav-wrapper">
              <button
                onClick={() => handleNavClick("#shop")}
                className="Nav-link"
              >
                Shop
              </button>
            </li>
            <li className="nav-wrapper">
              <button
                onClick={() => handleNavClick("#testimonials")}
                className="Nav-link"
              >
                Testimonials
              </button>
            </li>
            <li className="nav-wrapper wishlist">
              <Link to="/wishlist" className="Nav-link">
                Wishlist
              </Link>
            </li>
          </ul>
        </div>

        <div className="flex gap-[20px] items-center justify-center">
          <Link to="/wishlist" className="btn flex items-center justify-center">
            Wishlist <i className="ri-heart-line ml-1"></i>
          </Link>
          <i className="ri-menu-3-line btn bar" onClick={menuhandler}></i>
        </div>
      </div>
    </>
  );
}

export default Nav;
