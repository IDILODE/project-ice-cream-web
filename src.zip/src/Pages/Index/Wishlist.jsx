import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";

function Wishlist() {
  const [wishlist, setWishlist] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [modalContent, setModalContent] = useState(null);

  // Mengambil data dari localStorage saat halaman dimuat
  useEffect(() => {
    const savedWishlist = JSON.parse(localStorage.getItem("wishlist")) || [];
    setWishlist(savedWishlist);
  }, []);

  // Fungsi untuk menghapus item dari wishlist
  const toggleWishlist = (product) => {
    setWishlist((prevWishlist) => {
      const updatedWishlist = prevWishlist.filter(
        (item) => item.name !== product.name
      );
      localStorage.setItem("wishlist", JSON.stringify(updatedWishlist));
      return updatedWishlist;
    });
  };

  // Fungsi untuk membuka modal
  const openModal = (product) => {
    setModalContent(product);
    setModalOpen(true);
  };

  // Fungsi untuk menutup modal
  const closeModal = () => {
    setModalOpen(false);
    setModalContent(null);
  };

  const location = useLocation();
  const navigate = useNavigate();

  const handleNavClick = (hash) => {
    if (location.pathname !== "/") {
      // Pindah ke halaman home
      navigate("/");

      // Tunggu sebentar agar halaman home ter-load, lalu scroll ke elemen tujuan
      setTimeout(() => {
        const targetElement = document.getElementById(hash.replace("#", ""));
        if (targetElement) {
          targetElement.scrollIntoView({ behavior: "smooth" });
        }
      }, 500);
    } else {
      // Jika sudah di home, langsung scroll ke elemen
      document
        .getElementById(hash.replace("#", ""))
        ?.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <>
      <section id="wishlist">
        <h3 className="section_heading">Your Wishlist</h3>

        {/* Grid Wrapper */}
        <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-10 px-10">
          {wishlist.length === 0 ? (
            <p className="text-center col-span-4">No items in wishlist.</p>
          ) : (
            wishlist.map((product, index) => (
              <div
                key={index}
                className="w-full flex flex-col gap-2 relative card"
              >
                {/* Grid-Image */}
                <div className="w-full">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full"
                  />
                  <div className="absolute top-5 flex flex-col gap-2 right-5 icons-card hidden">
                    {/* Hapus dari wishlist */}
                    <i
                      className="ri-heart-fill text-red-500 icon-card cursor-pointer"
                      onClick={() => toggleWishlist(product)}
                    ></i>
                    {/* Buka modal preview */}
                    <i
                      className="ri-eye-line icon-card cursor-pointer"
                      onClick={() => openModal(product)}
                    ></i>
                  </div>
                </div>
                {/* Grid-Content */}
                <div className="flex flex-col gap-2 items-center">
                  <div>
                    {[...Array(5)].map((_, i) => (
                      <i
                        key={i}
                        className={
                          i < product.rating
                            ? "ri-star-fill text-yellow-500"
                            : "ri-star-line text-gray-400"
                        }
                      ></i>
                    ))}
                  </div>
                  <h2 className="text-lg font-bold text-rose-400 text-center">
                    {product.name}
                  </h2>
                  <span>{product.price}</span>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Background Blur Saat Modal Aktif */}
        {modalOpen && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-md z-40"></div>
        )}

        {/* Modal Pop-Up */}
        {modalOpen && modalContent && (
          <div className="fixed inset-0 flex items-center justify-center z-50">
            <div className="bg-white p-5 rounded-lg shadow-lg w-[90%] max-w-md relative">
              <img
                src={modalContent.image}
                alt="Preview"
                className="w-full rounded-md"
              />
              <h2 className="text-xl font-bold text-center mt-3">
                {modalContent.name}
              </h2>
              <p className="text-gray-600 text-center mt-2">
                {modalContent.description}
              </p>
              <p className="text-center text-sm text-gray-500 mt-1">
                Category:{" "}
                <span className="font-semibold">{modalContent.category}</span>
              </p>
              <div className="flex justify-center items-center gap-1 mt-3">
                {[...Array(5)].map((_, i) => (
                  <i
                    key={i}
                    className={
                      i < modalContent.rating
                        ? "ri-star-fill text-yellow-500"
                        : "ri-star-line text-gray-400"
                    }
                  ></i>
                ))}
              </div>
              <p className="text-center text-lg font-semibold mt-2 text-rose-500">
                {modalContent.price}
              </p>

              {/* Tombol "Tutup" & "Beli" Bersampingan */}
              <div className="flex gap-3 mt-4">
                {/* Tombol "Tutup" (Kiri) */}
                <button
                  onClick={closeModal}
                  className="w-full bg-rose-500 hover:bg-rose-600 text-white py-2 rounded-lg"
                >
                  Tutup
                </button>

                {/* Tombol "Beli" (Kanan) */}
                <button
                  className="p-15 w-full bg-orange-500 hover:bg-orange-600 text-white py-2 rounded-lg flex items-center justify-center gap-2"
                  onClick={() => alert(`Membeli ${modalContent.name}`)}
                >
                  <i className="ri-shopping-cart-2-line"></i> Beli
                </button>
              </div>
            </div>
          </div>
        )}
      </section>
      {/* Contact Section */}
      <section className="bg-black text-white flex flex-col gap-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 w-full gap-5 pb-9">
          <div className="flex flex-col gap-2">
            <span className="text-2xl text-red-600 font-bold">JejakKafe</span>

            <div className="flex flex-col mt-4">
              <span>Follow Us</span>

              <p className="text-gray-500 hover:text-white">
                Yuk, ikuti kami di media sosial dan jangan ketinggalan update
                seru seputar Jejak Kafe!
              </p>

              <div className="flex gap-4 mt-4">
                <a
                  href="https://www.instagram.com/jejakcafe?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw=="
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <i className="ri-instagram-line text-gray-500 hover:text-white cursor-pointer text-2xl"></i>
                </a>
              </div>
            </div>
          </div>
          <div className="flex flex-col gap-2">
            <h2 className="text-2xl mb-5">Usefull Links</h2>
            <p
              onClick={() => handleNavClick("#category")}
              className="text-gray-500 hover:text-white cursor-pointer"
            >
              Category
            </p>
            <p
              onClick={() => handleNavClick("#popular")}
              className="text-gray-500 hover:text-white cursor-pointer"
            >
              Popular
            </p>
            <p
              onClick={() => handleNavClick("#shop")}
              className="text-gray-500 hover:text-white cursor-pointer"
            >
              Shop
            </p>
            <p
              onClick={() => handleNavClick("#testimonials")}
              className="text-gray-500 hover:text-white cursor-pointer"
            >
              Testimonials
            </p>
          </div>
          <div className="flex flex-col gap-2">
            <h2 className="text-2xl">Find Store</h2>

            <p className="text-gray-500 hover:text-white">
            Jl. Brawijaya No.21 Kec. Manokwari Kab. Manokwari
            </p>
            <p className="text-gray-500 hover:text-white">
              Papua Barat, 98312, Indonesia
            </p>

            <h2 className="text-2xl mt-5">Call Now</h2>
            <a
              href="https://wa.me/6282266260726"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-500 hover:text-white"
            >
              +62 822-6626-0726
            </a>

            <a
              href="mailto:Jejakcafe@gmail.com"
              className="text-gray-500 hover:text-white"
            >
              Jejakcafe@gmail.com
            </a>
          </div>
          <div className="flex flex-col gap-2">
            <h2 className="text-2xl">Opening Hours</h2>
            <p className="text-gray-500 hover:text-white">Monday - Saturday</p>
            <p className="text-gray-500 hover:text-white">
            5:00 PM To 12:00 AM
            </p>
          </div>
        </div>

        <div className="w-full flex justify-center">
          <iframe
            className="w-full h-64 md:h-96 border-0 rounded-lg"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4332.197760609151!2d134.07497017532918!3d-0.8664833991251185!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2d540b3e85560795%3A0x2651f14540af0da4!2sJejak%20Cafe!5e1!3m2!1sid!2sid!4v1742826316742!5m2!1sid!2sid"
            width="600"
            height="450"
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          ></iframe>
        </div>

        <p className="text-center pt-8 border-t-1 border-gray-500">
          © 2025 JejakCafe. All Rights Reserved.
        </p>
      </section>
    </>
  );
}

export default Wishlist;
