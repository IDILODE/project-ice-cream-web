import React, { useState, useEffect } from "react";

import heroImage from "./../../assets/rev_home3_01.png";

import element00 from "./../../assets/H5_decor4.png";
import element01 from "./../../assets/rev_home3_04.png";
import element02 from "./../../assets/rev_home3_05.png";
import element03 from "./../../assets/rev_home3_06.png";

import slideImage00 from "./../../assets/h3_cat-5.jpg";
import slideImage01 from "./../../assets/h3_cat-4.jpg";
import slideImage02 from "./../../assets/h3_cat-1.jpg";
import slideImage03 from "./../../assets/h3_cat-2.jpg";
import slideImage04 from "./../../assets/h3_cat-3.jpg";
import slideImage05 from "./../../assets/h3_cat-7.jpg";

import slideImage06 from "./../../assets/product_18_1-600x600.jpg";
import slideImage07 from "./../../assets/product_3_1-600x600.jpg";
import slideImage08 from "./../../assets/product_5_1-600x600.jpg";
import slideImage09 from "./../../assets/product_19_1-600x600.jpg";

import slideImage10 from "./../../assets/product_12_1-600x600.jpg";
import slideImage11 from "./../../assets/product_1_1-600x600.jpg";
import slideImage12 from "./../../assets/product_2_2.jpg";
import slideImage13 from "./../../assets/product_2_3.jpg";
import slideImage14 from "./../../assets/product_2_4.jpg";
import slideImage15 from "./../../assets/Japanese_Drip.jpg";
import slideImage16 from "./../../assets/Kopi_Susu_Jejak.jpg";
import slideImage17 from "./../../assets/V60.jpg";
import slideImage18 from "./../../assets/Coffe_Mocktail.jpg";
import slideImage19 from "./../../assets/Coffe_Beer.jpg";
import slideImage20 from "./../../assets/Coffe_Pandan.jpg";
import slideImage21 from "./../../assets/Coffe_Vanilla_Latte.jpg";
import slideImage22 from "./../../assets/Coffe_Hazelnut.jpg";
import slideImage23 from "./../../assets/Coffe_Biscoff.jpg";
import slideImage24 from "./../../assets/Tea.jpg";
import slideImage25 from "./../../assets/Milo.jpg";
import slideImage26 from "./../../assets/Coklat.jpg";
import slideImage27 from "./../../assets/Lemon_Tea.jpg";
import slideImage28 from "./../../assets/Tiramisu.jpg";
import slideImage29 from "./../../assets/Avocado.jpg";
import slideImage30 from "./../../assets/Red_Velvet.jpg";
import slideImage31 from "./../../assets/Thai_Tea.jpg";
import slideImage32 from "./../../assets/Hazelnut.jpg";
import slideImage33 from "./../../assets/Taro.jpg";
import slideImage34 from "./../../assets/Butterscotch.jpg";
import slideImage35 from "./../../assets/Salted_caramel.jpg";
import slideImage36 from "./../../assets/Macha_Green_tea.jpg";
import slideImage37 from "./../../assets/Chocomint.jpg";
import slideImage38 from "./../../assets/Orange.jpg";
import slideImage39 from "./../../assets/Sirsak.jpg";
import slideImage40 from "./../../assets/Alpukat.jpg";
import slideImage41 from "./../../assets/BuahNaga.jpg";
import slideImage42 from "./../../assets/Mangga.jpg";
import slideImage43 from "./../../assets/Melon.jpg";
import slideImage44 from "./../../assets/Melon_Banana_Orange.jpg";
import slideImage45 from "./../../assets/Banana_BuahNaga.jpg";
import slideImage46 from "./../../assets/Manggo_Orange.jpg";
import slideImage47 from "./../../assets/Sirsak_BuahNaga.jpg";
import slideImage48 from "./../../assets/Avocado_Milk_Coffee.jpg";
import slideImage49 from "./../../assets/Banana_Milk_Coffee.jpg";
import slideImage50 from "./../../assets/Summer_Green.jpg";
import slideImage51 from "./../../assets/Strawberry_Shine.jpg";
import slideImage52 from "./../../assets/Lychee_Shine.jpg";
import slideImage53 from "./../../assets/Mango_Shine.jpg";
import slideImage54 from "./../../assets/Green_Apple.jpg";
import slideImage55 from "./../../assets/Watermelon_Shine.jpg";
import slideImage56 from "./../../assets/Happy_Soda.jpg";

const products = [
  {
    image: slideImage06,
    name: "Espresso",
    description: "Kopi hitam pekat dengan rasa kuat dan khas.",
    category: "Coffee",
    price: "15K",
    rating: 4,
  },
  {
    image: slideImage07,
    name: "Americano",
    description:
      "Kombinasi espresso dengan air panas untuk cita rasa lebih ringan.",
    category: "Coffee",
    price: "25K",
    rating: 5,
  },
  {
    image: slideImage08,
    name: "Long Black",
    description:
      "Mirip Americano tetapi dengan proses pembuatan yang berbeda untuk rasa lebih kaya.",
    category: "Coffee",
    price: "25K",
    rating: 4,
  },
  {
    image: slideImage09,
    name: "Cappuccino",
    description:
      "Perpaduan espresso, susu steamed, dan foam lembut di atasnya.",
    category: "Coffee",
    price: "30K",
    rating: 5,
  },
  {
    image: slideImage10,
    name: "Coffee Latte",
    description: "Espresso dengan susu steamed yang creamy dan lembut.",
    category: "Coffee",
    price: "30K",
    rating: 4,
  },
  {
    image: slideImage11,
    name: "Vietnam Drip",
    description:
      "Kopi khas Vietnam yang diseduh perlahan dengan susu kental manis.",
    category: "Coffee",
    price: "30K",
    rating: 5,
  },
  {
    image: slideImage12,
    name: "Coffee Mocha",
    description:
      "Perpaduan espresso, coklat, dan susu steamed untuk rasa manis dan creamy.",
    category: "Coffee",
    price: "35K",
    rating: 4,
  },
  {
    image: slideImage13,
    name: "Caramel Macchiato",
    description: "Espresso dengan susu steamed dan saus karamel di atasnya.",
    category: "Coffee",
    price: "35K",
    rating: 5,
  },
  {
    image: slideImage14,
    name: "Kopi Gula Aren",
    description: "Espresso dengan gula aren yang memberikan rasa manis alami.",
    category: "Coffee",
    price: "35K",
    rating: 4,
  },
  {
    image: slideImage15,
    name: "Japanese Drip",
    description:
      "Kopi yang diseduh dengan metode tetes untuk rasa yang lebih bersih dan smooth.",
    category: "Coffee",
    price: "35K",
    rating: 5,
  },
  {
    image: slideImage16,
    name: "Kopi Susu Jejak",
    description: "Espresso dengan susu dan gula aren khas Jejak Kafe.",
    category: "Coffee",
    price: "30K",
    rating: 4,
  },
  {
    image: slideImage17,
    name: "V60",
    description:
      "Kopi yang diseduh dengan metode pour-over untuk cita rasa lebih halus.",
    category: "Coffee",
    price: "35K",
    rating: 5,
  },
  {
    image: slideImage18,
    name: "Coffee Mocktail",
    description:
      "Perpaduan kopi dengan soda dan sirup buah untuk sensasi segar.",
    category: "Coffee",
    price: "35K",
    rating: 4,
  },
  {
    image: slideImage19,
    name: "Coffee Beer",
    description:
      "Kombinasi unik antara kopi dan soda yang memberikan efek berbusa seperti bir.",
    category: "Coffee",
    price: "35K",
    rating: 5,
  },
  {
    image: slideImage20,
    name: "Coffee Pandan",
    description:
      "Kopi dengan sentuhan pandan yang memberikan aroma khas dan rasa lembut.",
    category: "Coffee",
    price: "35K",
    rating: 4,
  },
  {
    image: slideImage21,
    name: "Coffee Vanilla Latte",
    description:
      "Latte dengan tambahan vanilla untuk rasa lebih creamy dan manis.",
    category: "Coffee",
    price: "35K",
    rating: 5,
  },
  {
    image: slideImage22,
    name: "Coffee Hazelnut",
    description:
      "Espresso dengan sirup hazelnut yang memberikan rasa kacang manis.",
    category: "Coffee",
    price: "35K",
    rating: 4,
  },
  {
    image: slideImage23,
    name: "Coffee Biscoff",
    description: "Kopi dengan rasa khas biskuit Biscoff yang manis dan gurih.",
    category: "Coffee",
    price: "35K",
    rating: 5,
  },
  {
    image: slideImage24,
    name: "Tea",
    description: "Teh klasik dengan rasa yang menyegarkan.",
    category: "Milk Base",
    price: "10K",
    rating: 4,
  },
  {
    image: slideImage25,
    name: "Milo",
    description: "Minuman coklat Milo yang nikmat dan kaya rasa.",
    category: "Milk Base",
    price: "30K",
    rating: 5,
  },
  {
    image: slideImage26,
    name: "Coklat",
    description: "Coklat panas yang creamy dengan rasa manis yang pas.",
    category: "Milk Base",
    price: "30K",
    rating: 4,
  },
  {
    image: slideImage27,
    name: "Lemon Tea",
    description:
      "Teh lemon segar dengan perpaduan rasa manis dan asam yang seimbang.",
    category: "Milk Base",
    price: "30K",
    rating: 5,
  },
  {
    image: slideImage28,
    name: "Tiramisu",
    description:
      "Minuman tiramisu dengan kombinasi kopi dan coklat yang lembut.",
    category: "Milk Base",
    price: "30K",
    rating: 4,
  },
  {
    image: slideImage29,
    name: "Avocado",
    description: "Minuman alpukat creamy dengan campuran susu yang lezat.",
    category: "Milk Base",
    price: "30K",
    rating: 5,
  },
  {
    image: slideImage30,
    name: "Red Velvet",
    description: "Minuman red velvet dengan rasa khas dan tekstur lembut.",
    category: "Milk Base",
    price: "30K",
    rating: 4,
  },
  {
    image: slideImage31,
    name: "Thai Tea",
    description: "Teh susu khas Thailand dengan aroma teh yang kuat.",
    category: "Milk Base",
    price: "30K",
    rating: 5,
  },
  {
    image: slideImage32,
    name: "Hazelnut",
    description: "Minuman susu dengan rasa hazelnut yang khas dan lezat.",
    category: "Milk Base",
    price: "30K",
    rating: 4,
  },
  {
    image: slideImage33,
    name: "Taro",
    description:
      "Minuman taro dengan rasa manis dan creamy yang menggugah selera.",
    category: "Milk Base",
    price: "30K",
    rating: 5,
  },
  {
    image: slideImage34,
    name: "Butterscotch",
    description:
      "Minuman butterscotch dengan kombinasi rasa karamel dan vanilla.",
    category: "Milk Base",
    price: "35K",
    rating: 4,
  },
  {
    image: slideImage35,
    name: "Salter Caramel",
    description:
      "Minuman salted caramel yang manis dengan sedikit sentuhan asin.",
    category: "Milk Base",
    price: "35K",
    rating: 5,
  },
  {
    image: slideImage36,
    name: "Matcha Green Tea",
    description: "Minuman matcha dengan rasa khas teh hijau yang autentik.",
    category: "Milk Base",
    price: "35K",
    rating: 4,
  },
  {
    image: slideImage37,
    name: "ChocoMint",
    description: "Minuman coklat dengan rasa mint yang menyegarkan.",
    category: "Milk Base",
    price: "35K",
    rating: 5,
  },
  {
    image: slideImage38,
    name: "Orange",
    description: "Jus jeruk segar dengan rasa manis dan asam yang menyegarkan.",
    category: "Juice",
    price: "40K",
    rating: 5,
  },
  {
    image: slideImage39,
    name: "Sirsak",
    description: "Jus sirsak dengan tekstur lembut dan rasa yang khas.",
    category: "Juice",
    price: "40K",
    rating: 4,
  },
  {
    image: slideImage40,
    name: "Alpukat",
    description: "Jus alpukat kental dengan rasa creamy yang nikmat.",
    category: "Juice",
    price: "40K",
    rating: 5,
  },
  {
    image: slideImage41,
    name: "Buah Naga",
    description: "Jus buah naga dengan warna cerah dan rasa yang eksotis.",
    category: "Juice",
    price: "40K",
    rating: 4,
  },
  {
    image: slideImage42,
    name: "Mangga",
    description: "Jus mangga manis dengan rasa yang segar dan kaya vitamin.",
    category: "Juice",
    price: "40K",
    rating: 5,
  },
  {
    image: slideImage43,
    name: "Melon",
    description: "Jus melon yang segar dengan aroma buah yang khas.",
    category: "Juice",
    price: "40K",
    rating: 4,
  },
  {
    image: slideImage44,
    name: "Melon, Banana & Orange",
    description:
      "Kombinasi segar melon, pisang, dan jeruk untuk rasa yang unik dan menyegarkan.",
    category: "Mixed Juice",
    price: "50K",
    rating: 5,
  },
  {
    image: slideImage45,
    name: "Banana & Buah Naga",
    description:
      "Perpaduan pisang yang manis dan buah naga yang eksotis, menciptakan sensasi baru dalam satu gelas.",
    category: "Mixed Juice",
    price: "50K",
    rating: 4,
  },
  {
    image: slideImage46,
    name: "Mango & Orange",
    description:
      "Rasa tropis dari mangga yang manis dan jeruk yang menyegarkan, cocok untuk melepas dahaga.",
    category: "Mixed Juice",
    price: "50K",
    rating: 5,
  },
  {
    image: slideImage47,
    name: "Sirsak & Buah Naga",
    description:
      "Kombinasi unik sirsak yang lembut dengan buah naga yang kaya akan manfaat.",
    category: "Mixed Juice",
    price: "50K",
    rating: 4,
  },
  {
    image: slideImage48,
    name: "Avocado Milk Coffee",
    description:
      "Kombinasi unik alpukat yang creamy dengan kopi berkualitas tinggi, memberikan rasa kaya dan lembut.",
    category: "Fruit X Coffee",
    price: "50K",
    rating: 5,
  },
  {
    image: slideImage49,
    name: "Banana Milk Coffee",
    description:
      "Paduan lezat pisang dan susu dengan sentuhan kopi yang kuat, menciptakan rasa yang seimbang dan nikmat.",
    category: "Fruit X Coffee",
    price: "50K",
    rating: 4,
  },
  {
    image: slideImage50,
    name: "Summer Green",
    description:
      "Mocktail segar dengan perpaduan lime dan mint yang menyegarkan.",
    category: "Mocktail",
    price: "35K",
    rating: 5,
  },
  {
    image: slideImage51,
    name: "Strawberry Shine",
    description: "Sensasi manis dan segar dari stroberi dengan sentuhan soda.",
    category: "Mocktail",
    price: "35K",
    rating: 4,
  },
  {
    image: slideImage52,
    name: "Lychee Shine",
    description:
      "Kombinasi unik dari leci dan soda, memberikan rasa yang segar dan menyenangkan.",
    category: "Mocktail",
    price: "35K",
    rating: 4,
  },
  {
    image: slideImage53,
    name: "Mango Shine",
    description:
      "Manisnya mangga berpadu sempurna dengan soda yang menyegarkan.",
    category: "Mocktail",
    price: "35K",
    rating: 5,
  },
  {
    image: slideImage54,
    name: "Green Apple",
    description: "Segarnya apel hijau dengan rasa asam-manis yang khas.",
    category: "Mocktail",
    price: "35K",
    rating: 4,
  },
  {
    image: slideImage55,
    name: "Watermelon Shine",
    description:
      "Kesegaran semangka dalam mocktail yang ringan dan menyenangkan.",
    category: "Mocktail",
    price: "35K",
    rating: 4,
  },
  {
    image: slideImage56,
    name: "Happy Soda",
    description:
      "Kombinasi soda dan susu dengan rasa manis yang bikin bahagia.",
    category: "Mocktail",
    price: "35K",
    rating: 5,
  },
];

import avatar01 from "./../../assets/avatar-1.jpg";
import avatar02 from "./../../assets/avatar-2.jpg";
import avatar03 from "./../../assets/avatar-3.jpg";
import avatar04 from "./../../assets/avatar-4.jpg";

import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import { Autoplay } from "swiper/modules";

function Index() {
  const [modalOpen, setModalOpen] = useState(false);
  const [modalContent, setModalContent] = useState(null);

  const openModal = (product) => {
    setModalContent(product);
    setModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
  };

  const [wishlist, setWishlist] = useState([]);

  useEffect(() => {
    const savedWishlist = JSON.parse(localStorage.getItem("wishlist")) || [];
    setWishlist(savedWishlist);
  }, []);

  const toggleWishlist = (product) => {
    setWishlist((prevWishlist) => {
      const isExist = prevWishlist.find((item) => item.name === product.name);
      let updatedWishlist;

      if (isExist) {
        updatedWishlist = prevWishlist.filter(
          (item) => item.name !== product.name
        );
      } else {
        updatedWishlist = [...prevWishlist, product];
      }

      localStorage.setItem("wishlist", JSON.stringify(updatedWishlist));
      return updatedWishlist;
    });
  };

  const scrollToSection = (id) => {
    const section = document.getElementById(id);
    if (section) {
      section.scrollIntoView({ behavior: "smooth" });
    }
  };

  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setTimeout(() => setVisible(true), 300); // Delay agar terlihat lebih halus
  }, []);

  return (
    <>
      <div className="flex flex-col gap-[20px] relative min-h-[90vh] bg-[#A67B5B]">
        <div className="w-full px-[12%] pt-[100px] flex gap-[20px] flex-col lg:flex-row">
          <div className="flex flex-col lg:w-[50%] w-full items-start gap-4 justify-center">
            <small className="text-4xl font-dancing z-[1]">Best Seller</small>
            <h2 className="text-7xl 2xl:text-8xl font-medium text-red-600 font-Kalnia z-[2]">
              Coffee
              <br />
              Cappuccino
            </h2>
            <p className="text-lg text-white z-[2]">
              Kombinasi sempurna dari espresso yang kuat, susu steamed yang
              creamy, dan foam lembut yang menggoda. Setiap tegukan memberikan
              sensasi kehangatan yang membangkitkan semangat. Dengan aroma khas
              yang menggoda dan rasa yang seimbang, Cappuccino ini menjadi
              favorit banyak pecinta kopi. Rasakan kelembutan dan kenikmatannya
              di setiap cangkir, sempurna untuk menemani harimu!
            </p>
            <button
              className="btn header-btn"
              onClick={() => openModal(products[3])}
            >
              Shop Now <i className="ri-arrow-right-line"></i>
            </button>
          </div>
          <div className="lg:w-[50%] full flex items-center justify-center z-[1] relative md:absolute right-0 bottom-0">
            <img
              src={heroImage}
              alt="header-image"
              className={`w-full sm:w-[600px] 2xl:w-[600px] transform transition-all duration-4000 ease-in-out ${
                visible
                  ? "translate-x-0 opacity-100 rotate-0"
                  : "translate-x-full opacity-0 rotate-[12npm0deg]"
              }`}
            />
          </div>

          <img
      src={element00}
      alt="element1"
      className={`w-[100px] h-[80px] absolute -top-[-80%] left-5 transform transition-all duration-1200 ease-in-out ${
        visible
          ? "translate-x-0 opacity-100 rotate-0"
          : "-translate-x-full opacity-0 rotate-[-180deg]"
      }`}
    />
          <img
      src={element01}
      alt="element2"
      className={`w-[80px] h-[80px] absolute -top-[-10%] lg:left-[90%] left-[65%] hidden sm:flex z-1 transform transition-all duration-2500 ease-in-out ${
        visible
          ? "translate-x-0 opacity-100 rotate-0"
          : "translate-x-full opacity-0 rotate-[10deg]"
      }`}
    />
         <img
  src={element02}
  alt="element3"
  className={`w-[140px] h-[140px] absolute -top-[1%] left-10 transform transition-all duration-1000 ease-in-out delay-500 ${
    visible
      ? "translate-x-0 opacity-100 rotate-0"
      : "-translate-x-full opacity-0 rotate-[90deg]"
  }`}
/>

<img
      src={element03}
      alt="element4"
      className={`w-[90px] h-[90px] absolute -top-[-85%] sm:-top-[-80%] lg:left-[85%] left-[-75%] z-1 transform transition-all duration-2800 ease-in-out ${
        visible
          ? "translate-x-0 opacity-100 rotate-0"
          : "translate-x-full opacity-0 rotate-[300deg]"
      }`}
    />
        </div>
      </div>

      {/* Category Section */}

      <section id="category">
        <h3 className="section_heading">Shop by Category</h3>

        <Swiper
          className="w-full mt-[80px]"
          slidesPerView={5}
          spaceBetween={10}
          autoplay={{
            delay: 2500,
          }}
          modules={[Autoplay]}
          loop={true}
          breakpoints={{
            0: {
              slidesPerView: 1.5,
            },
            768: {
              slidesPerView: 2.5,
            },
            1024: {
              slidesPerView: 4.5,
            },
          }}
        >
          <SwiperSlide>
            <div className="w-[180px] card group">
              <img
                src={slideImage00}
                alt="slider-image"
                className="w-full rounded-full mb-4"
              />

              <span className="Slide_text">Fruit x Kopi</span>
              <span className="text-center w-full text-base hidden group-hover:inline-block">
                2 Products
              </span>
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="w-[180px] card group">
              <img
                src={slideImage01}
                alt="slider-image"
                className="w-full rounded-full mb-4"
              />

              <span className="Slide_text">Mixed Juice</span>
              <span className="text-center w-full text-base hidden group-hover:inline-block">
                4 Products
              </span>
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="w-[180px] card group">
              <img
                src={slideImage02}
                alt="slider-image"
                className="w-full rounded-full mb-4"
              />

              <span className="Slide_text">Coffee</span>
              <span className="text-center w-full text-base hidden group-hover:inline-block">
                18 Products
              </span>
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="w-[180px] card group">
              <img
                src={slideImage03}
                alt="slider-image"
                className="w-full rounded-full mb-4"
              />

              <span className="Slide_text">Milk Base</span>
              <span className="text-center w-full text-base hidden group-hover:inline-block">
                14 Products
              </span>
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="w-[180px] card group">
              <img
                src={slideImage04}
                alt="slider-image"
                className="w-full rounded-full mb-4"
              />

              <span className="Slide_text">Juice</span>
              <span className="text-center w-full text-base hidden group-hover:inline-block">
                6 Products
              </span>
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="w-[180px] card group">
              <img
                src={slideImage05}
                alt="slider-image"
                className="w-full rounded-full mb-4"
              />

              <span className="Slide_text">Mocktail</span>
              <span className="text-center w-full text-base hidden group-hover:inline-block">
                7 Products
              </span>
            </div>
          </SwiperSlide>
        </Swiper>
      </section>

      <section>
        <div className="flex gap-[10px] flex-wrap lg:flex-nowrap">
          <div className="w-full sm:w-[46%] lg:w-[33%] h-[550px] p-6 flex flex-col items-center pt-15 gap-2 text-white relative overflow-hidden group">
            <div className="absolute inset-0 bg-black/50 z-[1]"></div>
            <div className="absolute inset-0 bg-[url(assets/h3_bn-2.jpg)] bg-cover bg-center transition-transform duration-500 group-hover:scale-110 group-hover:translate-x-2 group-hover:translate-y-2"></div>
            <div className="relative text-center drop-shadow-lg flex flex-col items-center gap-2 z-[2]">
              <small className="text-2xl">Save 20% off</small>
              <h3>Summer 2025</h3>
              <p className="text-center">
                Smooth & Refreshing, Bold & Flavorful, No Milk, Just Pure Coffee.
              </p>
              <button
                className="btn header-btn"
                onClick={() => openModal(products[1])}
              >
                Shop Now <i className="ri-arrow-right-line"></i>
              </button>
            </div>
          </div>
          <div className="w-full sm:w-[46%] lg:w-[33%] h-[550px] p-6 flex flex-col items-center pt-15 gap-2 text-white relative overflow-hidden group">
            <div className="absolute inset-0 bg-black/50 z-[1]"></div>
            <div className="absolute inset-0 bg-[url(assets/h3_bn-1.jpg)] bg-cover bg-center transition-transform duration-500 group-hover:scale-110 group-hover:-translate-x-2 group-hover:-translate-y-2"></div>
            <div className="relative text-center drop-shadow-lg flex flex-col items-center gap-2 z-[2]">
              <small className="text-2xl">Save 20% off</small>
              <h3>Summer 2025</h3>
              <p className="text-center">
                Exotic & Refreshing, Boldly Sweet, A Taste of Thailand.
              </p>
              <button
                className="btn header-btn"
                onClick={() => openModal(products[25])}
              >
                Shop Now <i className="ri-arrow-right-line"></i>
              </button>
            </div>
          </div>
          <div className="w-full lg:w-[33%] h-[550px] flex flex-col gap-10">
            <div className="relative h-[260px] w-full p-6 flex flex-col pt-4 gap-2 text-white overflow-hidden group">
              <div className="absolute inset-0 bg-black/50 z-[1]"></div>
              <div className="absolute inset-0 bg-[url(assets/h3_bn-4.jpg)] bg-cover bg-center transition-transform duration-500 group-hover:scale-110 group-hover:translate-x-2"></div>
              <div className="relative drop-shadow-lg z-[2]">
                <h3 className="text-3xl">Best Selling</h3>
                <p className="pt-20">
                  The #1 Best <br /> Kopi Susu Jejak.
                </p>
              </div>
            </div>
            <div className="relative h-[260px] w-full p-6 flex flex-col pt-4 gap-2 text-white overflow-hidden group">
              <div className="absolute inset-0 bg-black/50 z-[1]"></div>
              <div className="absolute inset-0 bg-[url(assets/h3_bn-3.jpg)] bg-cover bg-center transition-transform duration-500 group-hover:scale-110 group-hover:-translate-x-2"></div>
              <div className="relative drop-shadow-lg z-[2]">
                <h3 className="text-3xl">Best Selling</h3>
                <p className="pt-20">
                  Orange Juice <br /> Naturally Sweet & Light.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>


      {/* Background Blur Saat Modal Aktif */}
      {modalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-md z-40"></div>
      )}

      {/* Modal Pop-Up */}
      {modalOpen && modalContent && (
        <div className="fixed inset-0 flex items-center justify-center z-50">
          <div className="bg-white p-5 rounded-lg shadow-lg w-[90%] max-w-md relative">
            <img
              src={modalContent.image}
              alt="Preview"
              className="w-full rounded-md"
            />
            <h2 className="text-xl font-bold text-center mt-3">
              {modalContent.name}
            </h2>
            <p className="text-gray-600 text-center mt-2">
              {modalContent.description}
            </p>
            <p className="text-center text-sm text-gray-500 mt-1">
              Category:{" "}
              <span className="font-semibold">{modalContent.category}</span>
            </p>
            <div className="flex justify-center items-center gap-1 mt-3">
              {[...Array(5)].map((_, i) => (
                <i
                  key={i}
                  className={
                    i < modalContent.rating
                      ? "ri-star-fill text-yellow-500"
                      : "ri-star-line text-gray-400"
                  }
                ></i>
              ))}
            </div>
            <p className="text-center text-lg font-semibold mt-2 text-rose-500">
              {modalContent.price}
            </p>

            {/* Tombol "Tutup" & "Beli" Bersampingan */}
            <div className="flex gap-3 mt-4">
              {/* Tombol "Tutup" (Kiri) */}
              <button
                onClick={closeModal}
                className="w-full bg-rose-500 hover:bg-rose-600 text-white py-2 rounded-lg"
              >
                Tutup
              </button>

              {/* Tombol "Beli" (Kanan) */}
              <button
                className="p-15 w-full bg-orange-500 hover:bg-orange-600 text-white py-2 rounded-lg flex items-center justify-center gap-2"
                onClick={() => alert(`Membeli ${modalContent.name}`)}
              >
                <i className="ri-shopping-cart-2-line"></i> Beli
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Popular Drink Selections Section */}
      <section id="popular">
        <h3 className="section_heading">Popular Drink Selections</h3>

        <Swiper
          className="mt-20 w-full"
          slidesPerView={3}
          spaceBetween={30}
          autoplay={{ delay: 1750 }}
          loop={true}
          breakpoints={{
            0: { slidesPerView: 1.5 },
            768: { slidesPerView: 2.5 },
            1024: { slidesPerView: 3.5 },
          }}
          modules={[Autoplay]}
        >
          {products
            .filter((product) =>
              [slideImage06, slideImage10, slideImage11, slideImage17, slideImage25, slideImage30, slideImage42, slideImage46, slideImage50, slideImage56].includes(
                product.image
              )
            )
            .map((product, index) => (
              <SwiperSlide key={index}>
                <div className="w-full flex flex-col gap-2 relative card">
                  <div className="w-full">
                    <img
                      src={product.image}
                      alt="slide-image"
                      className="w-full"
                    />

                    <div className="absolute top-5 flex-col right-5 gap-3 icons-card hidden">
                      <i
                        className={`icon-card cursor-pointer ${
                          wishlist.some((item) => item.name === product.name)
                            ? "ri-heart-fill text-red-500"
                            : "ri-heart-line"
                        }`}
                        onClick={() => toggleWishlist(product)}
                      ></i>
                      <i
                        className="ri-eye-line icon-card cursor-pointer"
                        onClick={() => openModal(product)}
                      ></i>
                    </div>
                  </div>
                  <div className="flex flex-col items-center gap-2">
                    <div>
                      {[...Array(5)].map((_, i) => (
                        <i
                          key={i}
                          className={
                            i < product.rating
                              ? "ri-star-fill text-yellow-500"
                              : "ri-star-line text-gray-400"
                          }
                        ></i>
                      ))}
                    </div>
                    <h2 className="text-lg font-bold text-rose-400 text-center">
                      {product.name}
                    </h2>
                    <span>{product.price}</span>
                  </div>
                </div>
              </SwiperSlide>
            ))}
        </Swiper>
      </section>

      {/* Shop Section */}
      <section id="shop">
        <h3 className="section_heading">One Sip, Endless Joy</h3>

        {/* Grid Wrapper */}
        <div className="mt-30 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-10">
          {products.map((product, index) => (
            <div
              key={index}
              className="w-full flex flex-col gap-2 relative card"
            >
              {/* Grid-Image */}
              <div className="w-full">
                <img src={product.image} alt="slide-image" className="w-full" />
                <div className="absolute top-5 flex flex-col gap-2 right-5 hidden icons-card">
                  <i
                    className={`icon-card cursor-pointer ${
                      wishlist.some((item) => item.name === product.name)
                        ? "ri-heart-fill text-red-500"
                        : "ri-heart-line"
                    }`}
                    onClick={() => toggleWishlist(product)}
                  ></i>
                  <i
                    className="ri-eye-line icon-card cursor-pointer"
                    onClick={() => openModal(product)}
                  ></i>
                </div>
              </div>
              {/* Grid-Content */}
              <div className="flex flex-col gap-2 items-center">
                <div>
                  {[...Array(5)].map((_, i) => (
                    <i
                      key={i}
                      className={
                        i < product.rating
                          ? "ri-star-fill text-yellow-500"
                          : "ri-star-line text-gray-400"
                      }
                    ></i>
                  ))}
                </div>
                <h2 className="text-lg font-bold text-rose-400 text-center">
                  {product.name}
                </h2>
                <span>{product.price}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section>
        <div className="flex justify-between flex-wrap gap-5">
          <div className="flex items-center gap-4">
            <h3 className="text-6xl font-bold text-rose-500">1.5</h3>
            <p className="text-gray-400">
              Thousand Liters of <br />{" "}
              <span className="text-2xl text-black font-semibold">
                Coffee Brewed
              </span>
            </p>
          </div>
          <div className="flex items-center gap-4">
            <h3 className="text-6xl font-bold text-rose-500">19</h3>
            <p className="text-gray-400">
              Thousands <br />{" "}
              <span className="text-2xl text-black font-semibold">
                Cups Served
              </span>
            </p>
          </div>
          <div className="flex items-center gap-4">
            <h3 className="text-6xl font-bold text-rose-500">2</h3>
            <p className="text-gray-400">
              Years of <br />{" "}
              <span className="text-2xl text-black font-semibold">
                Our Experience
              </span>
            </p>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="bg-orange-100" id="testimonials">
        <h3 className="section_heading">Happy Clients Say</h3>

        <Swiper
          className="w-full mt-[100px] mb-[100px]"
          slidesPerView={3}
          spaceBetween={20}
          autoplay={{
            delay: 1500,
          }}
          modules={[Autoplay]}
          loop={true}
          breakpoints={{
            0: {
              slidesPerView: 1.5,
            },
            768: {
              slidesPerView: 2.5,
            },
            1024: {
              slidesPerView: 3,
            },
          }}
        >
          <SwiperSlide>
            <div className="w-full card group p-8 bg-white">
              <div className="flex items-start gap-3">
                <img
                  src={avatar01}
                  alt="avatar"
                  className="w-[50px] rounded-full mb-4"
                />
                <div className="flex flex-col">
                  <div>
                    <i className="ri-star-fill text-yellow-500"></i>
                    <i className="ri-star-fill text-yellow-500"></i>
                    <i className="ri-star-fill text-yellow-500"></i>
                    <i className="ri-star-fill text-yellow-500"></i>
                    <i className="ri-star-fill text-yellow-500"></i>
                  </div>
                  <span className="text-sm">Idil Ode</span>
                </div>
              </div>
              <p>
                Minuman ini memiliki rasa yang sangat lembut namun tetap kaya
                akan aroma kopi yang khas. Tidak terlalu manis, pas untuk
                dinikmati kapan saja. Saya sangat menikmati keseimbangan rasa
                yang dihadirkan.
              </p>
            </div>
          </SwiperSlide>

          <SwiperSlide>
            <div className="w-full card group p-8 bg-white">
              <div className="flex items-start gap-3">
                <img
                  src={avatar02}
                  alt="avatar"
                  className="w-[50px] rounded-full mb-4"
                />
                <div className="flex flex-col">
                  <div>
                    <i className="ri-star-fill text-yellow-500"></i>
                    <i className="ri-star-fill text-yellow-500"></i>
                    <i className="ri-star-fill text-yellow-500"></i>
                    <i className="ri-star-fill text-yellow-500"></i>
                    <i className="ri-star-line text-gray-400"></i>
                  </div>
                  <span className="text-sm">Pablo Escobar</span>
                </div>
              </div>
              <p>
                Kopinya memiliki cita rasa yang kuat namun tetap mudah
                dinikmati. Tekstur dan aftertaste-nya sangat memuaskan, terutama
                bagi pecinta kopi yang mencari kualitas premium dengan rasa yang
                autentik.
              </p>
            </div>
          </SwiperSlide>

          <SwiperSlide>
            <div className="w-full card group p-8 bg-white">
              <div className="flex items-start gap-3">
                <img
                  src={avatar03}
                  alt="avatar"
                  className="w-[50px] rounded-full mb-4"
                />
                <div className="flex flex-col">
                  <div>
                    <i className="ri-star-fill text-yellow-500"></i>
                    <i className="ri-star-fill text-yellow-500"></i>
                    <i className="ri-star-fill text-yellow-500"></i>
                    <i className="ri-star-fill text-yellow-500"></i>
                    <i className="ri-star-fill text-yellow-500"></i>
                  </div>
                  <span className="text-sm">Nur Intan Permatasari</span>
                </div>
              </div>
              <p>
                Aroma yang begitu menggoda dan rasa yang benar-benar menggugah
                selera. Tidak terlalu pahit, namun tetap memiliki karakter khas
                kopi yang kuat. Sangat cocok untuk menemani pagi atau sore hari.
              </p>
            </div>
          </SwiperSlide>

          <SwiperSlide>
            <div className="w-full card group p-8 bg-white">
              <div className="flex items-start gap-3">
                <img
                  src={avatar04}
                  alt="avatar"
                  className="w-[50px] rounded-full mb-4"
                />
                <div className="flex flex-col">
                  <div>
                    <i className="ri-star-fill text-yellow-500"></i>
                    <i className="ri-star-fill text-yellow-500"></i>
                    <i className="ri-star-fill text-yellow-500"></i>
                    <i className="ri-star-fill text-yellow-500"></i>
                    <i className="ri-star-line text-gray-400"></i>
                  </div>
                  <span className="text-sm">Ais Fernandes</span>
                </div>
              </div>
              <p>
                Satu kata: luar biasa! Rasa yang sangat seimbang antara pahit
                dan sedikit manis, tanpa menghilangkan karakter kopi aslinya.
                Teksturnya juga sangat halus, membuatnya semakin nikmat.
              </p>
            </div>
          </SwiperSlide>
        </Swiper>
      </section>

      {/* Contact Section */}
      <section className="bg-black text-white flex flex-col gap-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 w-full gap-5 pb-9">
          <div className="flex flex-col gap-2">
            <span className="text-2xl text-red-600 font-bold">JejakKafe</span>

            <div className="flex flex-col mt-4">
              <span>Follow Us</span>

              <p className="text-gray-500 hover:text-white">
                Yuk, ikuti kami di media sosial dan jangan ketinggalan update
                seru seputar Jejak Kafe!
              </p>

              <div className="flex gap-4 mt-4">
                <a
                  href="https://www.instagram.com/jejakcafe?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw=="
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Follow us on Instagram"
                >
                  <i className="ri-instagram-line text-gray-500 hover:text-white cursor-pointer text-2xl"></i>
                </a>
              </div>
            </div>
          </div>
          <div className="flex flex-col gap-2">
            <h2 className="text-2xl mb-5">Usefull Links</h2>
            <p
              className="text-gray-500 hover:text-white cursor-pointer"
              onClick={() => scrollToSection("category")}
            >
              Category
            </p>
            <p
              className="text-gray-500 hover:text-white cursor-pointer"
              onClick={() => scrollToSection("popular")}
            >
              Popular
            </p>
            <p
              className="text-gray-500 hover:text-white cursor-pointer"
              onClick={() => scrollToSection("shop")}
            >
              Shop
            </p>
            <p
              className="text-gray-500 hover:text-white cursor-pointer"
              onClick={() => scrollToSection("testimonials")}
            >
              Testimonials
            </p>
          </div>
          <div className="flex flex-col gap-2">
            <h2 className="text-2xl">Find Store</h2>

            <p className="text-gray-500 hover:text-white">
              Jl. Brawijaya No.21 Kec. Manokwari Kab. Manokwari
            </p>
            <p className="text-gray-500 hover:text-white">
              Papua Barat, 98312, Indonesia
            </p>

            <h2 className="text-2xl mt-5">Call Now</h2>
            <a
              href="https://wa.me/6282266260726"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-500 hover:text-white"
            >
              +62 822-6626-0726
            </a>

            <a
              href="mailto:Jejakcafe@gmail.com"
              className="text-gray-500 hover:text-white"
            >
              Jejakcafe@gmail.com
            </a>
          </div>
          <div className="flex flex-col gap-2">
            <h2 className="text-2xl">Opening Hours</h2>
            <p className="text-gray-500 hover:text-white">Monday - Saturday</p>
            <p className="text-gray-500 hover:text-white">
              5:00 PM To 12:00 AM
            </p>
          </div>
        </div>

        <div className="w-full flex justify-center">
          <iframe
            className="w-full h-64 md:h-96 border-0 rounded-lg"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4332.197760609151!2d134.07497017532918!3d-0.8664833991251185!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2d540b3e85560795%3A0x2651f14540af0da4!2sJejak%20Cafe!5e1!3m2!1sid!2sid!4v1742826316742!5m2!1sid!2sid"
            width="600"
            height="450"
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          ></iframe>
        </div>

        <p className="text-center pt-8 border-t-1 border-gray-500">
          © 2025 JejakCafe. All Rights Reserved.
        </p>
      </section>
    </>
  );
}

export default Index;
